package com.customer.crud.spring.angular.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.customer.crud.spring.angular.exception.ResourceNotFoundException;
import com.customer.crud.spring.angular.model.Customer;
import com.customer.crud.spring.angular.repository.CustomerRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/app")
public class CustomerController {

	@Autowired
	private CustomerRepository customerRepository;
	
	
	@GetMapping("customers")
	public List<Customer> getAllCustomers(){
		
		return customerRepository.findAll();
	}
	
	
	@GetMapping("/customers/{id}")
	public ResponseEntity<Customer> getCustomerById(@PathVariable(value="id") Long id) throws ResourceNotFoundException {
		
		Customer customer = customerRepository.findById(id).orElseThrow(()->
			new ResourceNotFoundException("Customer Not Found by this ID :" +id)
		);		
		return ResponseEntity.ok().body(customer);
	}
	
	
	@PostMapping("/customers")
	public Customer addCustomer( @Valid @RequestBody Customer customer) {
		
		return customerRepository.save(customer);
	}
	
	@DeleteMapping("/customers/{id}")
	public  Map<String,Boolean>  deleteCustomerbyId(@PathVariable(value = "id") Long id) throws ResourceNotFoundException {
	
		Customer customer = customerRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("Customer Not Found by this ID :" +id));
		
		customerRepository.delete(customer);
		
		Map<String,Boolean> map = new HashMap<String, Boolean>();
		map.put("deleted", Boolean.TRUE);
		return map;
		
	}
	
	@PutMapping("/customers/{id}")
	public ResponseEntity<Customer> updateCustomerById(@PathVariable(name="id") Long id,
			@RequestBody Customer updatedCustomer)throws ResourceNotFoundException {
		
		Customer customer = customerRepository.findById(id).orElseThrow(()->
			new ResourceNotFoundException("Customer Not Found by this ID :" +id)
		);
		
		customer.setFirstName(updatedCustomer.getFirstName());
		customer.setLastName(updatedCustomer.getLastName());
		customer.setMobileNumber(updatedCustomer.getMobileNumber());
		
		final Customer newCustomer =customerRepository.save(customer);
		return ResponseEntity.ok().body(newCustomer);
		
		
		
	}
	
}
